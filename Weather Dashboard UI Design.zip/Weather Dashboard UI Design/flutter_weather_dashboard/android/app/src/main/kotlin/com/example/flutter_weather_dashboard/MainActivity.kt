package com.example.flutter_weather_dashboard

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
