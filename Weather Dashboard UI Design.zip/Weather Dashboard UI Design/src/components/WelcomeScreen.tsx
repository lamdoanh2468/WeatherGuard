import { Card, CardContent } from "./ui/card";
import { Button } from "./ui/button";
import { 
  Cloud, 
  Thermometer, 
  Droplets, 
  Wind, 
  Leaf,
  Bell,
  BarChart3,
  Map,
  Shield,
  Zap,
  Eye,
  TrendingUp
} from "lucide-react";

interface WelcomeScreenProps {
  onGetStarted: () => void;
}

export function WelcomeScreen({ onGetStarted }: WelcomeScreenProps) {
  const features = [
    {
      icon: <Thermometer className="h-6 w-6" />,
      title: "Giám sát thời tiết",
      description: "Theo dõi nhiệt độ, độ ẩm, tốc độ gió và các chỉ số khác",
      gradient: "from-orange-500 to-red-500"
    },
    {
      icon: <Leaf className="h-6 w-6" />,
      title: "Chất lượng không khí",
      description: "AQI, PM2.5, PM10, NO₂, SO₂ từ nguồn uy tín AQICN",
      gradient: "from-green-500 to-emerald-500"
    },
    {
      icon: <BarChart3 className="h-6 w-6" />,
      title: "Biểu đồ phân tích",
      description: "Trực quan hóa dữ liệu theo thời gian, phát hiện xu hướng",
      gradient: "from-purple-500 to-pink-500"
    },
    {
      icon: <Map className="h-6 w-6" />,
      title: "Bản đồ môi trường",
      description: "Xem dữ liệu theo khu vực trên bản đồ trực quan",
      gradient: "from-cyan-500 to-blue-500"
    },
    {
      icon: <Bell className="h-6 w-6" />,
      title: "Cảnh báo thông minh",
      description: "Nhận thông báo khi chỉ số vượt ngưỡng nguy hiểm",
      gradient: "from-rose-500 to-pink-500"
    },
    {
      icon: <Shield className="h-6 w-6" />,
      title: "Khuyến nghị sức khỏe",
      description: "Lời khuyên dựa trên điều kiện môi trường hiện tại",
      gradient: "from-indigo-500 to-purple-500"
    }
  ];

  const stats = [
    { value: "12,000+", label: "Trạm quan trắc", icon: <Map className="h-5 w-5" /> },
    { value: "24/7", label: "Cập nhật liên tục", icon: <Zap className="h-5 w-5" /> },
    { value: "100%", label: "Miễn phí", icon: <Eye className="h-5 w-5" /> },
    { value: "Real-time", label: "Dữ liệu thời gian thực", icon: <TrendingUp className="h-5 w-5" /> }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-cyan-50 to-teal-50">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-20 left-10 w-72 h-72 bg-blue-400/20 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-cyan-400/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
          <div className="absolute top-1/2 left-1/2 w-80 h-80 bg-teal-400/20 rounded-full blur-3xl animate-pulse delay-500"></div>
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16">
          {/* Logo & Title */}
          <div className="text-center mb-12">
            <div className="flex justify-center mb-6">
              <div className="bg-gradient-to-br from-blue-600 to-cyan-500 w-24 h-24 rounded-3xl flex items-center justify-center shadow-2xl">
                <Cloud className="h-12 w-12 text-white" />
              </div>
            </div>
            <h1 className="text-6xl bg-gradient-to-r from-blue-600 via-cyan-600 to-teal-600 bg-clip-text text-transparent mb-4">
              WeatherGuard
            </h1>
            <p className="text-2xl text-gray-600 mb-8">
              Giám sát thời tiết & môi trường thông minh
            </p>
            <p className="text-lg text-gray-500 max-w-2xl mx-auto mb-8">
              Theo dõi chất lượng không khí, nhiệt độ, độ ẩm và các chỉ số môi trường quan trọng 
              từ các nguồn dữ liệu uy tín như OpenWeatherMap và AQICN
            </p>
            <div className="flex justify-center gap-4">
              <Button 
                onClick={onGetStarted}
                size="lg"
                className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white px-8 py-6 text-lg shadow-xl hover:shadow-2xl transition-all"
              >
                <Zap className="h-5 w-5 mr-2" />
                Bắt đầu ngay
              </Button>
              <Button 
                variant="outline"
                size="lg"
                className="px-8 py-6 text-lg border-2 hover:bg-blue-50"
              >
                Tìm hiểu thêm
              </Button>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-16">
            {stats.map((stat, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-all">
                <CardContent className="p-6 text-center">
                  <div className="flex justify-center mb-2 text-blue-600">
                    {stat.icon}
                  </div>
                  <div className="text-3xl bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent mb-1">
                    {stat.value}
                  </div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Features Grid */}
          <div className="mb-16">
            <h2 className="text-3xl text-center mb-12 bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
              Tính năng nổi bật
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {features.map((feature, index) => (
                <Card 
                  key={index}
                  className="border-0 shadow-lg hover:shadow-2xl transition-all duration-300 hover:scale-105 group"
                >
                  <CardContent className="p-6">
                    <div className={`bg-gradient-to-br ${feature.gradient} w-14 h-14 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                      <div className="text-white">
                        {feature.icon}
                      </div>
                    </div>
                    <h3 className="text-xl mb-2">{feature.title}</h3>
                    <p className="text-gray-600 text-sm">{feature.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Data Sources */}
          <Card className="border-0 shadow-xl bg-gradient-to-br from-blue-600 to-cyan-600 text-white">
            <CardContent className="p-8">
              <div className="text-center mb-6">
                <h3 className="text-2xl mb-2">Nguồn dữ liệu uy tín</h3>
                <p className="text-white/80">
                  WeatherGuard kết hợp dữ liệu từ các nguồn hàng đầu thế giới
                </p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                  <h4 className="text-xl mb-2">🌤️ OpenWeatherMap</h4>
                  <p className="text-white/80 text-sm mb-3">
                    Dữ liệu thời tiết toàn cầu với độ chính xác cao
                  </p>
                  <ul className="text-sm space-y-1 text-white/70">
                    <li>✓ Nhiệt độ, độ ẩm, áp suất</li>
                    <li>✓ Dự báo 5 ngày</li>
                    <li>✓ Cập nhật mỗi 10 phút</li>
                  </ul>
                </div>
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                  <h4 className="text-xl mb-2">🍃 AQICN</h4>
                  <p className="text-white/80 text-sm mb-3">
                    Chất lượng không khí từ 12,000+ trạm quan trắc
                  </p>
                  <ul className="text-sm space-y-1 text-white/70">
                    <li>✓ AQI, PM2.5, PM10</li>
                    <li>✓ NO₂, SO₂, CO, O₃</li>
                    <li>✓ Dữ liệu thời gian thực</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* CTA Footer */}
          <div className="text-center mt-16">
            <p className="text-gray-600 mb-4">
              Sẵn sàng theo dõi môi trường xung quanh bạn?
            </p>
            <Button 
              onClick={onGetStarted}
              size="lg"
              className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white px-12 py-6 text-lg shadow-xl hover:shadow-2xl transition-all"
            >
              Bắt đầu ngay - Miễn phí 100%
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
