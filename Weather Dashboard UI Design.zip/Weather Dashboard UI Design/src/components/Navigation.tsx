import { useState } from "react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { 
  Home, 
  BarChart3, 
  Map, 
  Bell, 
  User,
  Menu,
  X,
  Thermometer,
  Cloud,
  Wind,
  Settings
} from "lucide-react";

interface NavigationProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export function Navigation({ activeTab, setActiveTab }: NavigationProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navigationItems = [
    {
      id: "dashboard",
      label: "Dashboard",
      icon: <Home className="h-5 w-5" />,
      description: "Tổng quan thời tiết"
    },
    {
      id: "charts",
      label: "Biểu đồ",
      icon: <BarChart3 className="h-5 w-5" />,
      description: "Phân tích dữ liệu"
    },
    {
      id: "maps",
      label: "Bản đồ",
      icon: <Map className="h-5 w-5" />,
      description: "Dữ liệu địa lý"
    },
    {
      id: "alerts",
      label: "Cảnh báo",
      icon: <Bell className="h-5 w-5" />,
      description: "Thông báo & cài đặt",
      badge: 3
    },
    {
      id: "api-setup",
      label: "Cấu hình API",
      icon: <Settings className="h-5 w-5" />,
      description: "Thiết lập API keys"
    },
    {
      id: "account",
      label: "Tài khoản",
      icon: <User className="h-5 w-5" />,
      description: "Quản lý hồ sơ"
    }
  ];

  // Mock current weather for header
  const currentWeather = {
    location: "Hà Nội",
    temperature: 28,
    condition: "partly-cloudy",
    aqi: 85
  };

  const getWeatherIcon = () => {
    return <Cloud className="h-4 w-4 text-gray-500" />;
  };

  const getAQIColor = (aqi: number) => {
    if (aqi <= 50) return "text-green-600";
    if (aqi <= 100) return "text-yellow-600";
    if (aqi <= 150) return "text-orange-600";
    return "text-red-600";
  };

  return (
    <>
      {/* Header */}
      <header className="bg-gradient-to-r from-blue-600 via-cyan-500 to-teal-500 sticky top-0 z-50 shadow-lg">
        <div className="px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo & Title */}
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center border border-white/30 shadow-lg">
                  <Cloud className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl text-white hidden sm:block">WeatherGuard</h1>
                  <p className="text-xs text-white/80 hidden sm:block">Giám sát môi trường thông minh</p>
                  <h1 className="text-xl text-white sm:hidden">WG</h1>
                </div>
              </div>
            </div>

            {/* Current Weather Info - Desktop */}
            <div className="hidden md:flex items-center gap-4 text-sm">
              <div className="flex items-center gap-2 bg-white/20 backdrop-blur-sm px-3 py-2 rounded-lg border border-white/30">
                {getWeatherIcon()}
                <span className="text-white">{currentWeather.location}</span>
              </div>
              <div className="flex items-center gap-2 bg-white/20 backdrop-blur-sm px-3 py-2 rounded-lg border border-white/30">
                <Thermometer className="h-4 w-4 text-white" />
                <span className="text-white">{currentWeather.temperature}°C</span>
              </div>
              <div className="flex items-center gap-2 bg-white/20 backdrop-blur-sm px-3 py-2 rounded-lg border border-white/30">
                <Wind className="h-4 w-4 text-white" />
                <span className="text-white">
                  AQI {currentWeather.aqi}
                </span>
              </div>
            </div>

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="sm"
              className="md:hidden text-white hover:bg-white/20"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? (
                <X className="h-5 w-5" />
              ) : (
                <Menu className="h-5 w-5" />
              )}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden border-t bg-white">
            <div className="px-4 py-3 space-y-1">
              {navigationItems.map((item) => (
                <Button
                  key={item.id}
                  variant={activeTab === item.id ? "default" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => {
                    setActiveTab(item.id);
                    setIsMobileMenuOpen(false);
                  }}
                >
                  <div className="flex items-center gap-3">
                    {item.icon}
                    <div className="text-left">
                      <div className="flex items-center gap-2">
                        {item.label}
                        {item.badge && (
                          <Badge variant="destructive" className="h-5 w-5 p-0 text-xs">
                            {item.badge}
                          </Badge>
                        )}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {item.description}
                      </div>
                    </div>
                  </div>
                </Button>
              ))}
            </div>
            
            {/* Mobile Weather Info */}
            <div className="px-4 py-3 border-t bg-gray-50">
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  {getWeatherIcon()}
                  <span>{currentWeather.location} • {currentWeather.temperature}°C</span>
                </div>
                <span className={getAQIColor(currentWeather.aqi)}>
                  AQI {currentWeather.aqi}
                </span>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Desktop Sidebar Navigation */}
      <div className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0 md:pt-16">
        <div className="flex-1 flex flex-col min-h-0 bg-gradient-to-b from-slate-50 to-white border-r shadow-sm">
          <div className="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
            <nav className="mt-5 px-3 space-y-1">
              {navigationItems.map((item) => (
                <Button
                  key={item.id}
                  variant={activeTab === item.id ? "default" : "ghost"}
                  className="w-full justify-start h-auto p-3"
                  onClick={() => setActiveTab(item.id)}
                >
                  <div className="flex items-center gap-3 w-full">
                    {item.icon}
                    <div className="text-left flex-1">
                      <div className="flex items-center justify-between">
                        <span>{item.label}</span>
                        {item.badge && (
                          <Badge variant="destructive" className="h-5 w-5 p-0 text-xs">
                            {item.badge}
                          </Badge>
                        )}
                      </div>
                      <div className="text-xs text-muted-foreground text-left">
                        {item.description}
                      </div>
                    </div>
                  </div>
                </Button>
              ))}
            </nav>
          </div>

          {/* Weather Summary in Sidebar */}
          <div className="p-4 border-t bg-gradient-to-br from-blue-50 to-cyan-50">
            <div className="bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl p-4 shadow-lg">
              <div className="text-sm text-white/90 mb-2">Thời tiết hiện tại</div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="bg-white/20 backdrop-blur-sm p-2 rounded-lg">
                    {getWeatherIcon()}
                  </div>
                  <span className="text-2xl text-white">{currentWeather.temperature}°C</span>
                </div>
                <div className="text-right bg-white/20 backdrop-blur-sm px-3 py-2 rounded-lg">
                  <div className="text-xs text-white/80">AQI</div>
                  <div className="text-lg text-white">
                    {currentWeather.aqi}
                  </div>
                </div>
              </div>
              <div className="text-xs text-white/80 mt-2">
                📍 {currentWeather.location}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}