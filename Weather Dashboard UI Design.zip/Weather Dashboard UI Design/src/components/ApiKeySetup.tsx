import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Alert, AlertDescription, AlertTitle } from "./ui/alert";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Key, ExternalLink, AlertCircle, CheckCircle2, Info } from "lucide-react";
import { useState, useEffect } from "react";

export function ApiKeySetup() {
  const [openWeatherKey, setOpenWeatherKey] = useState("");
  const [aqicnKey, setAqicnKey] = useState("");
  const [saved, setSaved] = useState(false);

  // Load existing API keys khi component mount
  useEffect(() => {
    const existingOpenWeatherKey = localStorage.getItem('openweather_api_key');
    const existingAqicnKey = localStorage.getItem('aqicn_api_key');
    
    if (existingOpenWeatherKey && existingOpenWeatherKey !== 'YOUR_OPENWEATHERMAP_API_KEY') {
      setOpenWeatherKey(existingOpenWeatherKey);
    }
    if (existingAqicnKey && existingAqicnKey !== 'YOUR_AQICN_API_KEY') {
      setAqicnKey(existingAqicnKey);
    }
  }, []);

  const handleSave = () => {
    // Lưu API keys vào localStorage (tạm thời)
    // CẢNH BÁO: Trong production, cần lưu trữ an toàn hơn với backend
    if (openWeatherKey) {
      localStorage.setItem('openweather_api_key', openWeatherKey);
    }
    if (aqicnKey) {
      localStorage.setItem('aqicn_api_key', aqicnKey);
    }
    setSaved(true);
    setTimeout(() => {
      setSaved(false);
      // Reload trang để áp dụng API keys mới
      window.location.reload();
    }, 1500);
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-indigo-600 via-purple-500 to-pink-500 rounded-2xl shadow-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl text-white mb-2">⚙️ Cấu hình API Keys</h1>
            <p className="text-white/90">
              Thiết lập API keys để kết nối với các nguồn dữ liệu thời tiết và môi trường
            </p>
          </div>
          <div className="bg-white/20 backdrop-blur-sm p-4 rounded-xl border border-white/30">
            <Key className="h-8 w-8 text-white" />
          </div>
        </div>
      </div>

      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Lưu ý quan trọng về bảo mật</AlertTitle>
        <AlertDescription>
          Trong môi trường production, API keys không nên được lưu trữ trực tiếp ở frontend.
          Nên sử dụng backend (như Supabase) để lưu trữ và gọi API một cách an toàn.
        </AlertDescription>
      </Alert>

      <Tabs defaultValue="openweather" className="space-y-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="openweather">OpenWeatherMap</TabsTrigger>
          <TabsTrigger value="aqicn">AQICN</TabsTrigger>
        </TabsList>

        <TabsContent value="openweather" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Key className="h-5 w-5" />
                OpenWeatherMap API
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4>Thông tin</h4>
                  <Button variant="link" size="sm" asChild>
                    <a href="https://openweathermap.org/api" target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-4 w-4 mr-1" />
                      Trang chủ OpenWeatherMap
                    </a>
                  </Button>
                </div>
                <p className="text-sm text-muted-foreground">
                  OpenWeatherMap cung cấp dữ liệu thời tiết toàn cầu bao gồm nhiệt độ, độ ẩm, 
                  tốc độ gió, áp suất khí quyển và dự báo thời tiết.
                </p>
              </div>

              <Alert>
                <Info className="h-4 w-4" />
                <AlertTitle>Hướng dẫn lấy API Key</AlertTitle>
                <AlertDescription className="space-y-2 mt-2">
                  <ol className="list-decimal list-inside space-y-1 text-sm">
                    <li>Truy cập <a href="https://openweathermap.org/api" target="_blank" rel="noopener noreferrer" className="underline">openweathermap.org/api</a></li>
                    <li>Đăng ký tài khoản miễn phí</li>
                    <li>Vào phần "API keys" trong tài khoản của bạn</li>
                    <li>Tạo API key mới hoặc sao chép key hiện có</li>
                    <li>Dán key vào ô bên dưới</li>
                  </ol>
                </AlertDescription>
              </Alert>

              <div className="space-y-2">
                <Label htmlFor="openweather-key">API Key</Label>
                <div className="relative">
                  <Input
                    id="openweather-key"
                    type="text"
                    placeholder="Nhập OpenWeatherMap API Key"
                    value={openWeatherKey}
                    onChange={(e) => setOpenWeatherKey(e.target.value)}
                    className="pr-20"
                  />
                  {openWeatherKey && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-1 top-1 h-7"
                      onClick={() => setOpenWeatherKey('')}
                    >
                      Xóa
                    </Button>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">
                  Free tier: 1,000 lượt gọi/ngày, 60 lượt gọi/phút
                </p>
                {openWeatherKey && openWeatherKey.length > 10 && (
                  <p className="text-xs text-green-600">✓ API key đã được nhập</p>
                )}
              </div>

              <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <h4 className="text-sm mb-2">APIs được sử dụng:</h4>
                <ul className="text-xs space-y-1 text-muted-foreground">
                  <li>• Current Weather Data - Dữ liệu thời tiết hiện tại</li>
                  <li>• 5 Day / 3 Hour Forecast - Dự báo 5 ngày</li>
                  <li>• One Call API - Dữ liệu tổng hợp (nếu có)</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="aqicn" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Key className="h-5 w-5" />
                AQICN (World Air Quality Index)
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4>Thông tin</h4>
                  <Button variant="link" size="sm" asChild>
                    <a href="https://aqicn.org/api/" target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-4 w-4 mr-1" />
                      Trang chủ AQICN
                    </a>
                  </Button>
                </div>
                <p className="text-sm text-muted-foreground">
                  AQICN cung cấp dữ liệu chất lượng không khí toàn cầu bao gồm AQI, PM2.5, 
                  PM10, NO₂, SO₂, CO, O₃ từ hơn 12,000 trạm quan trắc trên thế giới.
                </p>
              </div>

              <Alert>
                <Info className="h-4 w-4" />
                <AlertTitle>Hướng dẫn lấy API Token</AlertTitle>
                <AlertDescription className="space-y-2 mt-2">
                  <ol className="list-decimal list-inside space-y-1 text-sm">
                    <li>Truy cập <a href="https://aqicn.org/data-platform/token/" target="_blank" rel="noopener noreferrer" className="underline">aqicn.org/data-platform/token/</a></li>
                    <li>Điền thông tin đăng ký (email, tên, mục đích sử dụng)</li>
                    <li>Nhận token qua email</li>
                    <li>Dán token vào ô bên dưới</li>
                  </ol>
                </AlertDescription>
              </Alert>

              <div className="space-y-2">
                <Label htmlFor="aqicn-key">API Token</Label>
                <div className="relative">
                  <Input
                    id="aqicn-key"
                    type="text"
                    placeholder="Nhập AQICN API Token"
                    value={aqicnKey}
                    onChange={(e) => setAqicnKey(e.target.value)}
                    className="pr-20"
                  />
                  {aqicnKey && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-1 top-1 h-7"
                      onClick={() => setAqicnKey('')}
                    >
                      Xóa
                    </Button>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">
                  Free tier: Không giới hạn lượt gọi (sử dụng hợp lý)
                </p>
                {aqicnKey && aqicnKey.length > 10 && (
                  <p className="text-xs text-green-600">✓ API token đã được nhập</p>
                )}
              </div>

              <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                <h4 className="text-sm mb-2">Dữ liệu cung cấp:</h4>
                <ul className="text-xs space-y-1 text-muted-foreground">
                  <li>• AQI (Air Quality Index) - Chỉ số chất lượng không khí tổng hợp</li>
                  <li>• PM2.5 & PM10 - Bụi mịn nguy hiểm</li>
                  <li>• NO₂, SO₂, CO, O₃ - Các chất ô nhiễm khác</li>
                  <li>• Dữ li���u theo thành phố hoặc tọa độ GPS</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle>Lưu cấu hình</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="border-yellow-200 bg-yellow-50">
            <AlertCircle className="h-4 w-4 text-yellow-600" />
            <AlertTitle className="text-yellow-900">Cảnh báo bảo mật</AlertTitle>
            <AlertDescription className="text-yellow-800">
              API keys hiện đang được lưu trong localStorage của trình duyệt. 
              Đây KHÔNG phải là cách lưu trữ an toàn cho production. 
              Trong ứng dụng thực tế, bạn nên sử dụng Supabase hoặc backend khác 
              để lưu trữ và xử lý API keys một cách an toàn.
            </AlertDescription>
          </Alert>

          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <Button 
                onClick={handleSave} 
                disabled={!openWeatherKey && !aqicnKey}
                className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700"
              >
                {saved ? (
                  <>
                    <CheckCircle2 className="h-4 w-4 mr-2" />
                    Đã lưu - Đang reload...
                  </>
                ) : (
                  <>
                    <Key className="h-4 w-4 mr-2" />
                    Lưu và Áp dụng API Keys
                  </>
                )}
              </Button>
              
              {(openWeatherKey || aqicnKey) && !saved && (
                <p className="text-sm text-muted-foreground">
                  Trang sẽ tự động reload sau khi lưu
                </p>
              )}
            </div>

            {/* Current Status */}
            <div className="bg-gray-50 rounded-lg p-3 space-y-2">
              <p className="text-sm">Trạng thái API Keys hiện tại:</p>
              <div className="flex items-center gap-2 text-sm">
                {localStorage.getItem('openweather_api_key') ? (
                  <>
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                    <span className="text-green-600">OpenWeatherMap: Đã cấu hình</span>
                  </>
                ) : (
                  <>
                    <AlertCircle className="h-4 w-4 text-gray-400" />
                    <span className="text-gray-600">OpenWeatherMap: Chưa cấu hình</span>
                  </>
                )}
              </div>
              <div className="flex items-center gap-2 text-sm">
                {localStorage.getItem('aqicn_api_key') ? (
                  <>
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                    <span className="text-green-600">AQICN: Đã cấu hình</span>
                  </>
                ) : (
                  <>
                    <AlertCircle className="h-4 w-4 text-gray-400" />
                    <span className="text-gray-600">AQICN: Chưa cấu hình</span>
                  </>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-blue-200 bg-blue-50">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Info className="h-5 w-5 text-blue-600 mt-0.5" />
            <div className="space-y-2">
              <h4 className="text-blue-900">Đề xuất: Sử dụng Supabase</h4>
              <p className="text-sm text-blue-800">
                Để tăng cường bảo mật và thêm nhiều tính năng như lưu trữ lịch sử dữ liệu, 
                quản lý user preferences, và scheduled functions để tự động cập nhật dữ liệu, 
                bạn nên tích hợp Supabase vào ứng dụng.
              </p>
              <div className="pt-2">
                <Button variant="outline" size="sm" className="bg-white">
                  Tìm hiểu về Supabase
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
