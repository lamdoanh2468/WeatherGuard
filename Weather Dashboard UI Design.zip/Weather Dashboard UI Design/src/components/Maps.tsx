import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { 
  MapPin, 
  Navigation, 
  Layers, 
  Wind, 
  Thermometer,
  Droplets,
  Leaf,
  AlertCircle
} from "lucide-react";

export function Maps() {
  // Mock location data with air quality and weather info
  const locations = [
    {
      id: 1,
      name: "Hoàn Kiếm",
      coordinates: { lat: 21.0285, lng: 105.8542 },
      aqi: 85,
      temperature: 28,
      humidity: 75,
      status: "moderate"
    },
    {
      id: 2,
      name: "Cầu Giấy",
      coordinates: { lat: 21.0334, lng: 105.7935 },
      aqi: 105,
      temperature: 29,
      humidity: 72,
      status: "unhealthy"
    },
    {
      id: 3,
      name: "Đống Đa",
      coordinates: { lat: 21.0175, lng: 105.8316 },
      aqi: 92,
      temperature: 27,
      humidity: 78,
      status: "moderate"
    },
    {
      id: 4,
      name: "Ba Đình",
      coordinates: { lat: 21.0314, lng: 105.8226 },
      aqi: 78,
      temperature: 26,
      humidity: 80,
      status: "good"
    },
    {
      id: 5,
      name: "Hai Bà Trưng",
      coordinates: { lat: 21.0122, lng: 105.8555 },
      aqi: 115,
      temperature: 30,
      humidity: 68,
      status: "unhealthy"
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "good": return "bg-green-500";
      case "moderate": return "bg-yellow-500";
      case "unhealthy": return "bg-orange-500";
      case "very-unhealthy": return "bg-red-500";
      default: return "bg-gray-500";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "good": return "Tốt";
      case "moderate": return "Trung bình";
      case "unhealthy": return "Kém";
      case "very-unhealthy": return "Rất xấu";
      default: return "Không xác định";
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-emerald-600 via-teal-500 to-cyan-500 rounded-2xl shadow-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl text-white mb-2">🗺️ Bản đồ Môi trường</h1>
            <p className="text-white/90">Theo dõi chất lượng không khí theo khu vực</p>
          </div>
          <div className="flex items-center gap-4">
            <Select defaultValue="aqi">
              <SelectTrigger className="w-[200px] bg-white/20 backdrop-blur-sm border-white/30 text-white">
                <SelectValue placeholder="Chọn loại dữ liệu" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="aqi">Chất lượng không khí</SelectItem>
                <SelectItem value="temperature">Nhiệt độ</SelectItem>
                <SelectItem value="humidity">Độ ẩm</SelectItem>
                <SelectItem value="wind">Tốc độ gió</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm" className="bg-white/20 backdrop-blur-sm border-white/30 text-white hover:bg-white/30">
              <Navigation className="h-4 w-4 mr-2" />
              Vị trí hiện tại
            </Button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Map Display */}
        <div className="lg:col-span-2">
          <Card className="h-[600px] border-0 shadow-xl bg-gradient-to-br from-emerald-50 to-teal-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <div className="bg-gradient-to-br from-emerald-500 to-teal-500 p-2 rounded-lg">
                  <MapPin className="h-5 w-5 text-white" />
                </div>
                Bản đồ chất lượng không khí - Hà Nội
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0 relative">
              <div className="relative h-full">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1737912133578-159cdde20086?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWF0aGVyJTIwbWFwJTIwdmlzdWFsaXphdGlvbnxlbnwxfHx8fDE3NTg4Njg3NzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Weather Map"
                  className="w-full h-[500px] object-cover rounded-b-lg"
                />
                
                {/* Overlay location markers */}
                <div className="absolute inset-0 p-4">
                  {locations.map((location) => (
                    <div
                      key={location.id}
                      className="absolute"
                      style={{
                        left: `${20 + location.id * 15}%`,
                        top: `${30 + location.id * 8}%`
                      }}
                    >
                      <div className="relative">
                        <div className={`w-6 h-6 rounded-full ${getStatusColor(location.status)} border-2 border-white shadow-lg cursor-pointer hover:scale-110 transition-transform`}></div>
                        <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-black text-white text-xs px-2 py-1 rounded opacity-0 hover:opacity-100 transition-opacity whitespace-nowrap">
                          {location.name}: AQI {location.aqi}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Legend */}
                <div className="absolute bottom-4 left-4 bg-white p-3 rounded-lg shadow-lg">
                  <h4 className="text-sm mb-2">Chú thích AQI</h4>
                  <div className="space-y-1 text-xs">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-green-500"></div>
                      <span>Tốt (0-50)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                      <span>Trung bình (51-100)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-orange-500"></div>
                      <span>Kém (101-150)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-red-500"></div>
                      <span>Xấu (151-200)</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Location Details */}
        <div className="space-y-4">
          <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-50 to-cyan-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <div className="bg-gradient-to-br from-blue-500 to-cyan-500 p-2 rounded-lg">
                  <Layers className="h-5 w-5 text-white" />
                </div>
                Chi tiết khu vực
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {locations.map((location) => (
                <div 
                  key={location.id}
                  className="p-3 bg-white border-0 rounded-xl shadow-sm hover:shadow-md cursor-pointer transition-all hover:scale-105"
                >
                  <div className="flex items-center justify-between mb-2">
                    <h4>{location.name}</h4>
                    <Badge className={`${getStatusColor(location.status)} text-white`}>
                      {getStatusText(location.status)}
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-2 text-sm">
                    <div className="flex items-center gap-1">
                      <Leaf className="h-3 w-3 text-green-600" />
                      <span>AQI: {location.aqi}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Thermometer className="h-3 w-3 text-orange-600" />
                      <span>{location.temperature}°C</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Droplets className="h-3 w-3 text-blue-600" />
                      <span>{location.humidity}%</span>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Current Warnings */}
          <Card className="border-0 shadow-lg bg-gradient-to-br from-orange-50 to-red-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <div className="bg-gradient-to-br from-orange-500 to-red-500 p-2 rounded-lg">
                  <AlertCircle className="h-5 w-5 text-white" />
                </div>
                Cảnh báo hiện tại
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-start gap-3 p-3 bg-orange-50 border border-orange-200 rounded-lg">
                <AlertCircle className="h-5 w-5 text-orange-500 mt-0.5" />
                <div>
                  <p className="text-sm">
                    <strong>Cầu Giấy & Hai Bà Trưng:</strong> AQI vượt mức an toàn
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Khuyến nghị hạn chế hoạt động ngoài trời
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-3 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                <Wind className="h-5 w-5 text-yellow-600 mt-0.5" />
                <div>
                  <p className="text-sm">
                    <strong>Toàn thành phố:</strong> Gió nhẹ, ô nhiễm có thể tích tụ
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Dự kiến cải thiện vào chiều tối
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Map Controls */}
          <Card className="border-0 shadow-lg bg-gradient-to-br from-purple-50 to-pink-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <div className="bg-gradient-to-br from-purple-500 to-pink-500 p-2 rounded-lg">
                  <Layers className="h-5 w-5 text-white" />
                </div>
                Điều khiển bản đồ
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button variant="outline" className="w-full justify-start">
                <Thermometer className="h-4 w-4 mr-2" />
                Hiện bản đồ nhiệt
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Wind className="h-4 w-4 mr-2" />
                Hiện hướng gió
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Droplets className="h-4 w-4 mr-2" />
                Hiện độ ẩm
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Leaf className="h-4 w-4 mr-2" />
                Chỉ số chất lượng không khí
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}