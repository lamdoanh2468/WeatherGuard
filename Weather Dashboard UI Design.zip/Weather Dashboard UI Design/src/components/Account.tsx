import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Switch } from "./ui/switch";
import { Separator } from "./ui/separator";
import { 
  User, 
  Settings, 
  Shield, 
  Bell,
  MapPin,
  Mail,
  Phone,
  Calendar,
  Activity,
  BarChart3,
  Lock,
  Eye,
  EyeOff,
  Download,
  Trash2,
  LogOut
} from "lucide-react";
import { useState } from "react";

export function Account() {
  const [showPassword, setShowPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);

  // Mock user data
  const userData = {
    name: "Nguyễn Văn An",
    email: "nguyen.van.an@email.com",
    phone: "+84 123 456 789",
    location: "Hoàn Kiếm, Hà Nội",
    joinDate: "2024-01-15",
    avatar: "",
    preferences: {
      notifications: true,
      darkMode: false,
      language: "vi",
      temperatureUnit: "celsius",
      timezone: "Asia/Ho_Chi_Minh"
    }
  };

  // Mock statistics
  const userStats = {
    alertsReceived: 127,
    daysActive: 45,
    locationsTracked: 3,
    dataPointsViewed: 2543
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1>Quản lý Tài khoản</h1>
        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
          Tài khoản đã xác thực
        </Badge>
      </div>

      <Tabs defaultValue="profile" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="profile" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            Hồ sơ
          </TabsTrigger>
          <TabsTrigger value="preferences" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            Tùy chọn
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            Bảo mật
          </TabsTrigger>
          <TabsTrigger value="activity" className="flex items-center gap-2">
            <Activity className="h-4 w-4" />
            Hoạt động
          </TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="space-y-6">
          {/* Profile Overview */}
          <Card>
            <CardHeader>
              <CardTitle>Thông tin cá nhân</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center gap-6">
                <Avatar className="h-24 w-24">
                  <AvatarImage src={userData.avatar} alt={userData.name} />
                  <AvatarFallback className="text-lg">
                    {userData.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div className="space-y-2">
                  <h3>{userData.name}</h3>
                  <p className="text-muted-foreground">{userData.email}</p>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4" />
                    Tham gia từ {new Date(userData.joinDate).toLocaleDateString('vi-VN')}
                  </div>
                  <Button variant="outline" size="sm">
                    Thay đổi ảnh đại diện
                  </Button>
                </div>
              </div>

              <Separator />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Họ và tên</Label>
                    <Input id="name" defaultValue={userData.name} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" defaultValue={userData.email} />
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="phone">Số điện thoại</Label>
                    <Input id="phone" defaultValue={userData.phone} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="location">Vị trí chính</Label>
                    <div className="flex items-center gap-2">
                      <Input id="location" defaultValue={userData.location} />
                      <Button variant="outline" size="sm">
                        <MapPin className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="bio">Giới thiệu</Label>
                <Textarea 
                  id="bio" 
                  placeholder="Viết một vài dòng giới thiệu về bản thân..."
                  rows={3}
                />
              </div>

              <div className="flex justify-end">
                <Button>Cập nhật thông tin</Button>
              </div>
            </CardContent>
          </Card>

          {/* Account Statistics */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Thống kê tài khoản
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center p-4 border rounded-lg">
                  <div className="text-2xl mb-1">{userStats.alertsReceived}</div>
                  <div className="text-sm text-muted-foreground">Cảnh báo nhận được</div>
                </div>
                <div className="text-center p-4 border rounded-lg">
                  <div className="text-2xl mb-1">{userStats.daysActive}</div>
                  <div className="text-sm text-muted-foreground">Ngày hoạt động</div>
                </div>
                <div className="text-center p-4 border rounded-lg">
                  <div className="text-2xl mb-1">{userStats.locationsTracked}</div>
                  <div className="text-sm text-muted-foreground">Vị trí theo dõi</div>
                </div>
                <div className="text-center p-4 border rounded-lg">
                  <div className="text-2xl mb-1">{userStats.dataPointsViewed}</div>
                  <div className="text-sm text-muted-foreground">Dữ liệu đã xem</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="preferences" className="space-y-6">
          {/* Display Preferences */}
          <Card>
            <CardHeader>
              <CardTitle>Tùy chọn hiển thị</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Chế độ tối</Label>
                  <p className="text-sm text-muted-foreground">Sử dụng giao diện tối</p>
                </div>
                <Switch defaultChecked={userData.preferences.darkMode} />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label>Ngôn ngữ</Label>
                  <p className="text-sm text-muted-foreground">Chọn ngôn ngữ hiển thị</p>
                </div>
                <Select defaultValue={userData.preferences.language}>
                  <SelectTrigger className="w-[120px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="vi">Tiếng Việt</SelectItem>
                    <SelectItem value="en">English</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label>Đơn vị nhiệt độ</Label>
                  <p className="text-sm text-muted-foreground">Celsius hoặc Fahrenheit</p>
                </div>
                <Select defaultValue={userData.preferences.temperatureUnit}>
                  <SelectTrigger className="w-[120px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="celsius">°C</SelectItem>
                    <SelectItem value="fahrenheit">°F</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Notification Preferences */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5" />
                Tùy chọn thông báo
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Thông báo đẩy</Label>
                  <p className="text-sm text-muted-foreground">Nhận thông báo trên thiết bị</p>
                </div>
                <Switch defaultChecked={userData.preferences.notifications} />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label>Email hàng ngày</Label>
                  <p className="text-sm text-muted-foreground">Báo cáo thời tiết hàng ngày</p>
                </div>
                <Switch />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label>Cảnh báo khẩn cấp</Label>
                  <p className="text-sm text-muted-foreground">Cảnh báo thời tiết nguy hiểm</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label>Báo cáo tuần</Label>
                  <p className="text-sm text-muted-foreground">Tổng hợp dữ liệu hàng tuần</p>
                </div>
                <Switch defaultChecked />
              </div>
            </CardContent>
          </Card>

          {/* Data & Privacy */}
          <Card>
            <CardHeader>
              <CardTitle>Dữ liệu & Quyền riêng tư</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Chia sẻ dữ liệu vị trí</Label>
                  <p className="text-sm text-muted-foreground">Giúp cải thiện dự báo khu vực</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label>Phân tích sử dụng</Label>
                  <p className="text-sm text-muted-foreground">Giúp cải thiện ứng dụng</p>
                </div>
                <Switch />
              </div>
              <Separator />
              <div className="space-y-2">
                <Button variant="outline" className="w-full justify-start">
                  <Download className="h-4 w-4 mr-2" />
                  Tải xuống dữ liệu của tôi
                </Button>
                <Button variant="outline" className="w-full justify-start text-red-600 hover:text-red-700">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Xóa tất cả dữ liệu
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          {/* Change Password */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5" />
                Thay đổi mật khẩu
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="current-password">Mật khẩu hiện tại</Label>
                <div className="relative">
                  <Input 
                    id="current-password" 
                    type={showPassword ? "text" : "password"}
                    placeholder="Nhập mật khẩu hiện tại"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="new-password">Mật khẩu mới</Label>
                <div className="relative">
                  <Input 
                    id="new-password" 
                    type={showNewPassword ? "text" : "password"}
                    placeholder="Nhập mật khẩu mới"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={() => setShowNewPassword(!showNewPassword)}
                  >
                    {showNewPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirm-password">Xác nhận mật khẩu mới</Label>
                <Input 
                  id="confirm-password" 
                  type="password"
                  placeholder="Nhập lại mật khẩu mới"
                />
              </div>
              <Button>Cập nhật mật khẩu</Button>
            </CardContent>
          </Card>

          {/* Two-Factor Authentication */}
          <Card>
            <CardHeader>
              <CardTitle>Xác thực hai yếu tố (2FA)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Xác thực qua SMS</Label>
                  <p className="text-sm text-muted-foreground">Gửi mã xác thực qua tin nhắn</p>
                </div>
                <Switch />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label>Ứng dụng xác thực</Label>
                  <p className="text-sm text-muted-foreground">Sử dụng Google Authenticator</p>
                </div>
                <Button variant="outline" size="sm">Thiết lập</Button>
              </div>
            </CardContent>
          </Card>

          {/* Login Sessions */}
          <Card>
            <CardHeader>
              <CardTitle>Phiên đăng nhập</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <div className="flex items-center gap-2">
                      <div className="text-sm">Chrome trên Windows</div>
                      <Badge variant="secondary" className="bg-green-100 text-green-700">Hiện tại</Badge>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Hà Nội, Việt Nam • Lần cuối: vừa xong
                    </div>
                  </div>
                  <Button variant="outline" size="sm" disabled>
                    Thiết bị này
                  </Button>
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <div className="text-sm">Safari trên iPhone</div>
                    <div className="text-xs text-muted-foreground">
                      Hà Nội, Việt Nam • Lần cuối: 2 giờ trước
                    </div>
                  </div>
                  <Button variant="outline" size="sm">
                    Đăng xuất
                  </Button>
                </div>
              </div>
              <Button variant="outline" className="w-full">
                Đăng xuất tất cả thiết bị khác
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="activity" className="space-y-6">
          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle>Hoạt động gần đây</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-start gap-3 p-3 border rounded-lg">
                  <div className="w-2 h-2 rounded-full bg-green-500 mt-2"></div>
                  <div>
                    <div className="text-sm">Đăng nhập thành công</div>
                    <div className="text-xs text-muted-foreground">
                      Chrome trên Windows • 15 phút trước
                    </div>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-3 border rounded-lg">
                  <div className="w-2 h-2 rounded-full bg-blue-500 mt-2"></div>
                  <div>
                    <div className="text-sm">Thay đổi cài đặt cảnh báo AQI</div>
                    <div className="text-xs text-muted-foreground">
                      Ngưỡng cảnh báo từ 120 → 100 • 2 giờ trước
                    </div>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-3 border rounded-lg">
                  <div className="w-2 h-2 rounded-full bg-orange-500 mt-2"></div>
                  <div>
                    <div className="text-sm">Nhận cảnh báo nhiệt độ cao</div>
                    <div className="text-xs text-muted-foreground">
                      36°C tại Hoàn Kiếm • 4 giờ trước
                    </div>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-3 border rounded-lg">
                  <div className="w-2 h-2 rounded-full bg-purple-500 mt-2"></div>
                  <div>
                    <div className="text-sm">Xem báo cáo biểu đồ tuần</div>
                    <div className="text-xs text-muted-foreground">
                      Dữ liệu AQI và nhiệt độ • 1 ngày trước
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Account Actions */}
          <Card>
            <CardHeader>
              <CardTitle className="text-red-600">Vùng nguy hiểm</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 border-red-200 bg-red-50 rounded-lg">
                <h4 className="text-red-800 mb-2">Xóa tài khoản</h4>
                <p className="text-sm text-red-700 mb-3">
                  Thao tác này sẽ xóa vĩnh viễn tài khoản và toàn bộ dữ liệu của bạn. 
                  Không thể hoàn tác.
                </p>
                <Button variant="destructive" size="sm">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Xóa tài khoản
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Logout Button */}
      <div className="flex justify-center pt-6">
        <Button variant="outline" className="flex items-center gap-2">
          <LogOut className="h-4 w-4" />
          Đăng xuất
        </Button>
      </div>
    </div>
  );
}