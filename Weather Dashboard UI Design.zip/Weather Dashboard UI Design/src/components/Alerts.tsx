import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Slider } from "./ui/slider";
import { Switch } from "./ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { 
  Bell, 
  AlertTriangle, 
  AlertCircle, 
  CheckCircle,
  Settings,
  History,
  Thermometer,
  Droplets,
  Wind,
  Leaf,
  Trash2,
  Plus
} from "lucide-react";

export function Alerts() {
  // Mock alert history data
  const alertHistory = [
    {
      id: 1,
      type: "aqi",
      title: "Chỉ số AQI vượt ngưỡng",
      message: "AQI tại Cầu Giấy đạt 105, vượt ngưỡng cảnh báo 100",
      timestamp: "2024-12-12 14:30",
      severity: "warning",
      location: "Cầu Giấy",
      value: 105,
      threshold: 100,
      read: false
    },
    {
      id: 2,
      type: "temperature",
      title: "Nhiệt độ cao bất thường",
      message: "Nhiệt độ đạt 36°C, vượt ngưỡng cảnh báo 35°C",
      timestamp: "2024-12-12 13:15",
      severity: "high",
      location: "Hoàn Kiếm",
      value: 36,
      threshold: 35,
      read: true
    },
    {
      id: 3,
      type: "humidity",
      title: "Độ ẩm thấp",
      message: "Độ ẩm không khí giảm xuống 30%, dưới ngưỡng 40%",
      timestamp: "2024-12-12 10:45",
      severity: "info",
      location: "Ba Đình",
      value: 30,
      threshold: 40,
      read: true
    },
    {
      id: 4,
      type: "aqi",
      title: "Cải thiện chất lượng không khí",
      message: "AQI tại Đống Đa giảm xuống 65, trở lại mức an toàn",
      timestamp: "2024-12-12 09:20",
      severity: "success",
      location: "Đống Đa",
      value: 65,
      threshold: 80,
      read: true
    }
  ];

  // Mock alert settings
  const alertSettings = [
    {
      id: "temperature",
      name: "Nhiệt độ",
      icon: <Thermometer className="h-4 w-4" />,
      enabled: true,
      thresholdHigh: 35,
      thresholdLow: 10,
      unit: "°C"
    },
    {
      id: "humidity",
      name: "Độ ẩm",
      icon: <Droplets className="h-4 w-4" />,
      enabled: true,
      thresholdHigh: 85,
      thresholdLow: 30,
      unit: "%"
    },
    {
      id: "aqi",
      name: "Chỉ số AQI",
      icon: <Leaf className="h-4 w-4" />,
      enabled: true,
      thresholdHigh: 100,
      thresholdLow: 0,
      unit: ""
    },
    {
      id: "wind",
      name: "Tốc độ gió",
      icon: <Wind className="h-4 w-4" />,
      enabled: false,
      thresholdHigh: 50,
      thresholdLow: 0,
      unit: "km/h"
    }
  ];

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "high": return <AlertTriangle className="h-4 w-4 text-red-500" />;
      case "warning": return <AlertCircle className="h-4 w-4 text-orange-500" />;
      case "info": return <AlertCircle className="h-4 w-4 text-blue-500" />;
      case "success": return <CheckCircle className="h-4 w-4 text-green-500" />;
      default: return <AlertCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "high": return "border-red-200 bg-red-50";
      case "warning": return "border-orange-200 bg-orange-50";
      case "info": return "border-blue-200 bg-blue-50";
      case "success": return "border-green-200 bg-green-50";
      default: return "border-gray-200 bg-gray-50";
    }
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString('vi-VN') + ' ' + date.toLocaleTimeString('vi-VN', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-rose-600 via-pink-500 to-fuchsia-500 rounded-2xl shadow-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl text-white mb-2">🔔 Cảnh báo & Thông báo</h1>
            <p className="text-white/90">Quản lý cảnh báo và cấu hình ngưỡng</p>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="bg-white/20 backdrop-blur-sm text-white border-white/30">
              {alertHistory.filter(alert => !alert.read).length} chưa đọc
            </Badge>
            <Button variant="outline" size="sm" className="bg-white/20 backdrop-blur-sm border-white/30 text-white hover:bg-white/30">
              <Bell className="h-4 w-4 mr-2" />
              Đánh dấu tất cả đã đọc
            </Button>
          </div>
        </div>
      </div>

      <Tabs defaultValue="history" className="space-y-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="history" className="flex items-center gap-2">
            <History className="h-4 w-4" />
            Lịch sử cảnh báo
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            Cài đặt cảnh báo
          </TabsTrigger>
        </TabsList>

        <TabsContent value="history" className="space-y-4">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-gradient-to-br from-blue-500 to-cyan-500 border-0 shadow-lg hover:shadow-xl transition-all hover:scale-105">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-white/80">Hôm nay</p>
                    <p className="text-3xl text-white">4</p>
                  </div>
                  <div className="bg-white/20 backdrop-blur-sm p-3 rounded-xl">
                    <Bell className="h-8 w-8 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-red-500 to-rose-500 border-0 shadow-lg hover:shadow-xl transition-all hover:scale-105">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-white/80">Mức cao</p>
                    <p className="text-3xl text-white">1</p>
                  </div>
                  <div className="bg-white/20 backdrop-blur-sm p-3 rounded-xl">
                    <AlertTriangle className="h-8 w-8 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-orange-500 to-amber-500 border-0 shadow-lg hover:shadow-xl transition-all hover:scale-105">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-white/80">Cảnh báo</p>
                    <p className="text-3xl text-white">2</p>
                  </div>
                  <div className="bg-white/20 backdrop-blur-sm p-3 rounded-xl">
                    <AlertCircle className="h-8 w-8 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-green-500 to-emerald-500 border-0 shadow-lg hover:shadow-xl transition-all hover:scale-105">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-white/80">Thành công</p>
                    <p className="text-3xl text-white">1</p>
                  </div>
                  <div className="bg-white/20 backdrop-blur-sm p-3 rounded-xl">
                    <CheckCircle className="h-8 w-8 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Alert List */}
          <Card>
            <CardHeader>
              <CardTitle>Cảnh báo gần đây</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {alertHistory.map((alert) => (
                <div
                  key={alert.id}
                  className={`p-4 rounded-lg border ${getSeverityColor(alert.severity)} ${
                    !alert.read ? 'border-l-4 border-l-blue-500' : ''
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3 flex-1">
                      {getSeverityIcon(alert.severity)}
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className={!alert.read ? 'font-semibold' : ''}>{alert.title}</h4>
                          {!alert.read && (
                            <Badge variant="secondary" className="bg-blue-100 text-blue-700 text-xs">
                              Mới
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">{alert.message}</p>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span>{formatTimestamp(alert.timestamp)}</span>
                          <span>📍 {alert.location}</span>
                          <span>
                            Giá trị: {alert.value}{alert.type === 'aqi' ? '' : alert.type === 'temperature' ? '°C' : alert.type === 'humidity' ? '%' : 'km/h'}
                            / Ngưỡng: {alert.threshold}{alert.type === 'aqi' ? '' : alert.type === 'temperature' ? '°C' : alert.type === 'humidity' ? '%' : 'km/h'}
                          </span>
                        </div>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          {/* Notification Preferences */}
          <Card>
            <CardHeader>
              <CardTitle>Tùy chọn thông báo</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Thông báo đẩy</Label>
                  <p className="text-sm text-muted-foreground">Nhận thông báo trên thiết bị</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label>Email thông báo</Label>
                  <p className="text-sm text-muted-foreground">Gửi cảnh báo qua email</p>
                </div>
                <Switch />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label>Âm thanh cảnh báo</Label>
                  <p className="text-sm text-muted-foreground">Phát âm thanh khi có cảnh báo</p>
                </div>
                <Switch defaultChecked />
              </div>
            </CardContent>
          </Card>

          {/* Alert Thresholds */}
          <Card>
            <CardHeader>
              <CardTitle>Ngưỡng cảnh báo</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {alertSettings.map((setting) => (
                <div key={setting.id} className="space-y-4 p-4 border rounded-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {setting.icon}
                      <Label>{setting.name}</Label>
                    </div>
                    <Switch defaultChecked={setting.enabled} />
                  </div>
                  
                  {setting.enabled && (
                    <div className="space-y-4 pl-6">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label className="text-sm">Ngưỡng cao</Label>
                          <div className="flex items-center gap-2 mt-1">
                            <Input
                              type="number"
                              defaultValue={setting.thresholdHigh}
                              className="w-20"
                            />
                            <span className="text-sm text-muted-foreground">{setting.unit}</span>
                          </div>
                        </div>
                        {setting.id !== 'aqi' && (
                          <div>
                            <Label className="text-sm">Ngưỡng thấp</Label>
                            <div className="flex items-center gap-2 mt-1">
                              <Input
                                type="number"
                                defaultValue={setting.thresholdLow}
                                className="w-20"
                              />
                              <span className="text-sm text-muted-foreground">{setting.unit}</span>
                            </div>
                          </div>
                        )}
                      </div>
                      
                      {/* Slider for visual threshold setting */}
                      <div className="space-y-2">
                        <Label className="text-sm">Điều chỉnh ngưỡng cao</Label>
                        <Slider
                          defaultValue={[setting.thresholdHigh]}
                          max={setting.id === 'aqi' ? 300 : setting.id === 'temperature' ? 50 : setting.id === 'humidity' ? 100 : 100}
                          min={0}
                          step={1}
                          className="w-full"
                        />
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Location Settings */}
          <Card>
            <CardHeader>
              <CardTitle>Vị trí theo dõi</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Vị trí hiện tại</Label>
                  <p className="text-sm text-muted-foreground">Hoàn Kiếm, Hà Nội</p>
                </div>
                <Button variant="outline" size="sm">
                  Thay đổi
                </Button>
              </div>
              
              <div className="space-y-2">
                <Label>Vị trí bổ sung</Label>
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-2 border rounded">
                    <span className="text-sm">Cầu Giấy, Hà Nội</span>
                    <Button variant="ghost" size="sm">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="flex items-center justify-between p-2 border rounded">
                    <span className="text-sm">Đống Đa, Hà Nội</span>
                    <Button variant="ghost" size="sm">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="w-full">
                  <Plus className="h-4 w-4 mr-2" />
                  Thêm vị trí
                </Button>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end">
            <Button>Lưu cài đặt</Button>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}