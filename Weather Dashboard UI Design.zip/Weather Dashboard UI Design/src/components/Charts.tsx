import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { LineChart, Line, AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { TrendingUp, BarChart3, Activity } from "lucide-react";

export function Charts() {
  // Mock historical data
  const temperatureData = [
    { date: "01/12", temperature: 25, humidity: 70, aqi: 85 },
    { date: "02/12", temperature: 27, humidity: 65, aqi: 92 },
    { date: "03/12", temperature: 29, humidity: 68, aqi: 88 },
    { date: "04/12", temperature: 26, humidity: 75, aqi: 95 },
    { date: "05/12", temperature: 28, humidity: 72, aqi: 90 },
    { date: "06/12", temperature: 30, humidity: 63, aqi: 105 },
    { date: "07/12", temperature: 32, humidity: 60, aqi: 110 },
    { date: "08/12", temperature: 28, humidity: 78, aqi: 85 },
    { date: "09/12", temperature: 25, humidity: 80, aqi: 82 },
    { date: "10/12", temperature: 27, humidity: 73, aqi: 88 },
    { date: "11/12", temperature: 29, humidity: 69, aqi: 94 },
    { date: "12/12", temperature: 31, humidity: 65, aqi: 98 }
  ];

  const airQualityData = [
    { date: "01/12", pm25: 32, pm10: 45, no2: 28, so2: 15 },
    { date: "02/12", pm25: 38, pm10: 52, no2: 32, so2: 18 },
    { date: "03/12", pm25: 35, pm10: 48, no2: 25, so2: 12 },
    { date: "04/12", pm25: 42, pm10: 58, no2: 35, so2: 22 },
    { date: "05/12", pm25: 39, pm10: 55, no2: 30, so2: 19 },
    { date: "06/12", pm25: 48, pm10: 65, no2: 40, so2: 25 },
    { date: "07/12", pm25: 52, pm10: 72, no2: 45, so2: 28 },
    { date: "08/12", pm25: 36, pm10: 49, no2: 27, so2: 16 },
    { date: "09/12", pm25: 33, pm10: 44, no2: 24, so2: 14 },
    { date: "10/12", pm25: 37, pm10: 51, no2: 29, so2: 17 },
    { date: "11/12", pm25: 41, pm10: 56, no2: 33, so2: 20 },
    { date: "12/12", pm25: 44, pm10: 60, no2: 36, so2: 23 }
  ];

  const weeklyData = [
    { week: "Tuần 1", avgTemp: 27, avgAQI: 88, rainfall: 12 },
    { week: "Tuần 2", avgTemp: 29, avgAQI: 95, rainfall: 8 },
    { week: "Tuần 3", avgTemp: 26, avgAQI: 82, rainfall: 25 },
    { week: "Tuần 4", avgTemp: 30, avgAQI: 105, rainfall: 5 }
  ];

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-purple-600 via-pink-500 to-rose-500 rounded-2xl shadow-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl text-white mb-2">📊 Biểu đồ & Phân tích</h1>
            <p className="text-white/90">Theo dõi xu hướng và phân tích dữ liệu môi trường</p>
          </div>
          <div className="flex items-center gap-4">
            <Select defaultValue="30days">
              <SelectTrigger className="w-[180px] bg-white/20 backdrop-blur-sm border-white/30 text-white">
                <SelectValue placeholder="Chọn khoảng thời gian" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7days">7 ngày qua</SelectItem>
                <SelectItem value="30days">30 ngày qua</SelectItem>
                <SelectItem value="3months">3 tháng qua</SelectItem>
                <SelectItem value="1year">1 năm qua</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <Tabs defaultValue="temperature" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="temperature">Nhiệt độ & Độ ẩm</TabsTrigger>
          <TabsTrigger value="airquality">Chất lượng không khí</TabsTrigger>
          <TabsTrigger value="trends">Xu hướng tổng quan</TabsTrigger>
          <TabsTrigger value="weekly">Báo cáo tuần</TabsTrigger>
        </TabsList>

        <TabsContent value="temperature" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="border-0 shadow-lg bg-gradient-to-br from-orange-50 to-red-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <div className="bg-gradient-to-br from-orange-500 to-red-500 p-2 rounded-lg">
                    <TrendingUp className="h-5 w-5 text-white" />
                  </div>
                  Biến động Nhiệt độ (12 ngày qua)
                </CardTitle>
              </CardHeader>
              <CardContent className="bg-white rounded-xl p-4 m-4 mt-0 shadow-sm">
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={temperatureData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip 
                      formatter={(value, name) => [
                        `${value}${name === 'temperature' ? '°C' : '%'}`,
                        name === 'temperature' ? 'Nhiệt độ' : 'Độ ẩm'
                      ]}
                    />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="temperature" 
                      stroke="#f97316" 
                      strokeWidth={2}
                      name="Nhiệt độ"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-50 to-cyan-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <div className="bg-gradient-to-br from-blue-500 to-cyan-500 p-2 rounded-lg">
                    <Activity className="h-5 w-5 text-white" />
                  </div>
                  Độ ẩm không khí
                </CardTitle>
              </CardHeader>
              <CardContent className="bg-white rounded-xl p-4 m-4 mt-0 shadow-sm">
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={temperatureData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`${value}%`, 'Độ ẩm']} />
                    <Area 
                      type="monotone" 
                      dataKey="humidity" 
                      stroke="#3b82f6" 
                      fill="#3b82f6"
                      fillOpacity={0.6}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="airquality" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Chỉ số AQI theo thời gian</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={temperatureData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`${value}`, 'AQI']} />
                    <Line 
                      type="monotone" 
                      dataKey="aqi" 
                      stroke="#ef4444" 
                      strokeWidth={3}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Thành phần ô nhiễm</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={airQualityData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="pm25" fill="#f59e0b" name="PM2.5" />
                    <Bar dataKey="pm10" fill="#84cc16" name="PM10" />
                    <Bar dataKey="no2" fill="#6366f1" name="NO₂" />
                    <Bar dataKey="so2" fill="#ec4899" name="SO₂" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="trends" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Xu hướng tổng quan - Nhiệt độ vs AQI</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={temperatureData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip />
                  <Legend />
                  <Line 
                    yAxisId="left"
                    type="monotone" 
                    dataKey="temperature" 
                    stroke="#f97316" 
                    strokeWidth={2}
                    name="Nhiệt độ (°C)"
                  />
                  <Line 
                    yAxisId="right"
                    type="monotone" 
                    dataKey="aqi" 
                    stroke="#ef4444" 
                    strokeWidth={2}
                    name="AQI"
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="weekly" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Nhiệt độ trung bình
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={weeklyData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="week" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`${value}°C`, 'Nhiệt độ TB']} />
                    <Bar dataKey="avgTemp" fill="#f97316" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>AQI trung bình</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={weeklyData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="week" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`${value}`, 'AQI TB']} />
                    <Bar dataKey="avgAQI" fill="#ef4444" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Lượng mưa</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={weeklyData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="week" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`${value}mm`, 'Lượng mưa']} />
                    <Bar dataKey="rainfall" fill="#3b82f6" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}