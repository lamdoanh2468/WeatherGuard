import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Button } from "./ui/button";
import { useWeatherData } from "../hooks/useWeatherData";
import { 
  Thermometer, 
  Droplets, 
  Wind, 
  Eye, 
  Sun, 
  Cloud, 
  CloudRain,
  AlertTriangle,
  Leaf,
  RefreshCw,
  Loader2
} from "lucide-react";

export function Dashboard() {
  const { weather, airQuality, forecast, loading, error, lastUpdated, refetch } = useWeatherData('Hanoi', true);

  // Kết hợp dữ liệu từ API hoặc sử dụng giá trị mặc định
  const currentWeather = {
    location: weather?.location || "Hà Nội, Việt Nam",
    temperature: weather?.temperature || 28,
    humidity: weather?.humidity || 75,
    windSpeed: weather?.windSpeed || 12,
    visibility: weather?.visibility || 8,
    condition: weather?.condition || "partly-cloudy",
    conditionText: weather?.conditionText || "Có mây",
    aqi: airQuality?.aqi || 85,
    pm25: airQuality?.pm25 || 35,
    pm10: airQuality?.pm10 || 45,
    no2: airQuality?.no2 || 25,
    so2: airQuality?.so2 || 15,
    co: airQuality?.co || 0.8
  };

  // Sử dụng dữ liệu dự báo từ API hoặc mock data
  const hourlyForecast = forecast.length > 0 ? forecast : [
    { time: "6h", temp: 25, condition: "sunny" },
    { time: "9h", temp: 27, condition: "partly-cloudy" },
    { time: "12h", temp: 30, condition: "cloudy" },
    { time: "15h", temp: 32, condition: "partly-cloudy" },
    { time: "18h", temp: 29, condition: "cloudy" },
    { time: "21h", temp: 26, condition: "rainy" },
    { time: "24h", temp: 24, condition: "rainy" },
    { time: "3h", temp: 23, condition: "cloudy" }
  ];

  const getAQIStatus = (aqi: number) => {
    if (aqi <= 50) return { text: "Tốt", color: "bg-green-500", textColor: "text-green-700" };
    if (aqi <= 100) return { text: "Trung bình", color: "bg-yellow-500", textColor: "text-yellow-700" };
    if (aqi <= 150) return { text: "Kém", color: "bg-orange-500", textColor: "text-orange-700" };
    if (aqi <= 200) return { text: "Xấu", color: "bg-red-500", textColor: "text-red-700" };
    return { text: "Rất xấu", color: "bg-purple-500", textColor: "text-purple-700" };
  };

  const getWeatherIcon = (condition: string) => {
    switch (condition) {
      case "sunny": return <Sun className="h-6 w-6 text-yellow-500" />;
      case "partly-cloudy": return <Cloud className="h-6 w-6 text-gray-500" />;
      case "cloudy": return <Cloud className="h-6 w-6 text-gray-600" />;
      case "rainy": return <CloudRain className="h-6 w-6 text-blue-500" />;
      default: return <Sun className="h-6 w-6 text-yellow-500" />;
    }
  };

  const aqiStatus = getAQIStatus(currentWeather.aqi);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 via-cyan-500 to-teal-500 rounded-2xl shadow-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl text-white mb-2">Dashboard WeatherGuard</h1>
            <p className="text-white/90 flex items-center gap-2">
              📍 {currentWeather.location}
            </p>
            {lastUpdated && (
              <p className="text-xs text-white/70 mt-1">
                Cập nhật lần cuối: {lastUpdated.toLocaleTimeString('vi-VN')}
              </p>
            )}
          </div>
          <div className="flex items-center gap-4">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={refetch}
              disabled={loading}
              className="bg-white/20 backdrop-blur-sm border-white/30 text-white hover:bg-white/30"
            >
              {loading ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <RefreshCw className="h-4 w-4 mr-2" />
              )}
              Làm mới
            </Button>
            <div className="text-right bg-white/20 backdrop-blur-sm rounded-xl p-4 border border-white/30">
              <div className="flex items-center gap-2">
                <div className="bg-white/20 p-2 rounded-lg">
                  {getWeatherIcon(currentWeather.condition)}
                </div>
                <span className="text-4xl text-white">{currentWeather.temperature}°C</span>
              </div>
              <p className="text-sm text-white/80 mt-1">{currentWeather.conditionText}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Info/Error Messages */}
      {!localStorage.getItem('openweather_api_key') && !localStorage.getItem('aqicn_api_key') && (
        <Card className="border-blue-200 bg-gradient-to-r from-blue-50 to-cyan-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="bg-blue-500 p-2 rounded-lg">
                <AlertTriangle className="h-5 w-5 text-white" />
              </div>
              <div className="flex-1">
                <p className="text-blue-900">
                  <strong>Đang sử dụng dữ liệu mô phỏng</strong>
                </p>
                <p className="text-sm text-blue-700 mt-1">
                  Để nhận dữ liệu thời tiết thực, vui lòng cấu hình API keys tại tab "Cấu hình API"
                </p>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => window.location.hash = '#api-setup'}
                className="bg-blue-500 text-white border-blue-600 hover:bg-blue-600"
              >
                Cấu hình ngay
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
      
      {error && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-red-700">
              <AlertTriangle className="h-5 w-5" />
              <p>{error}</p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Main Weather Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-orange-500 to-red-500 border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/80">Nhiệt độ</p>
                <p className="text-3xl text-white">{currentWeather.temperature}°C</p>
              </div>
              <div className="bg-white/20 backdrop-blur-sm p-3 rounded-xl">
                <Thermometer className="h-8 w-8 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-500 to-cyan-500 border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/80">Độ ẩm</p>
                <p className="text-3xl text-white">{currentWeather.humidity}%</p>
              </div>
              <div className="bg-white/20 backdrop-blur-sm p-3 rounded-xl">
                <Droplets className="h-8 w-8 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-teal-500 to-emerald-500 border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/80">Tốc độ gió</p>
                <p className="text-3xl text-white">{currentWeather.windSpeed} km/h</p>
              </div>
              <div className="bg-white/20 backdrop-blur-sm p-3 rounded-xl">
                <Wind className="h-8 w-8 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500 to-indigo-500 border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/80">Tầm nhìn</p>
                <p className="text-3xl text-white">{currentWeather.visibility} km</p>
              </div>
              <div className="bg-white/20 backdrop-blur-sm p-3 rounded-xl">
                <Eye className="h-8 w-8 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Air Quality Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-0 shadow-lg bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className="bg-gradient-to-br from-green-500 to-emerald-500 p-2 rounded-lg">
                <Leaf className="h-5 w-5 text-white" />
              </div>
              Chỉ số Chất lượng Không khí (AQI)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-white rounded-xl p-4 shadow-sm">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-4xl bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">{currentWeather.aqi}</p>
                  <Badge className={`${aqiStatus.color} text-white mt-2`}>
                    {aqiStatus.text}
                  </Badge>
                </div>
                <div className="text-right">
                  <Progress value={currentWeather.aqi / 3} className="w-32 h-3" />
                  <p className="text-xs text-muted-foreground mt-1">0-300 AQI</p>
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white rounded-lg p-3 shadow-sm hover:shadow-md transition-shadow">
                <p className="text-xs text-muted-foreground">PM2.5</p>
                <p className="text-lg">{currentWeather.pm25} μg/m³</p>
              </div>
              <div className="bg-white rounded-lg p-3 shadow-sm hover:shadow-md transition-shadow">
                <p className="text-xs text-muted-foreground">PM10</p>
                <p className="text-lg">{currentWeather.pm10} μg/m³</p>
              </div>
              <div className="bg-white rounded-lg p-3 shadow-sm hover:shadow-md transition-shadow">
                <p className="text-xs text-muted-foreground">NO₂</p>
                <p className="text-lg">{currentWeather.no2} μg/m³</p>
              </div>
              <div className="bg-white rounded-lg p-3 shadow-sm hover:shadow-md transition-shadow">
                <p className="text-xs text-muted-foreground">SO₂</p>
                <p className="text-lg">{currentWeather.so2} μg/m³</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Health Recommendations */}
        <Card className="border-0 shadow-lg bg-gradient-to-br from-amber-50 via-yellow-50 to-orange-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className="bg-gradient-to-br from-amber-500 to-orange-500 p-2 rounded-lg">
                <AlertTriangle className="h-5 w-5 text-white" />
              </div>
              Khuyến nghị Sức khỏe
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="p-4 bg-gradient-to-r from-yellow-500 to-amber-500 rounded-xl shadow-md text-white">
                <p className="text-sm">
                  <strong>⚠️ Nhóm nhạy cảm:</strong> Hạn chế hoạt động ngoài trời kéo dài
                </p>
              </div>
              <div className="p-4 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-xl shadow-md text-white">
                <p className="text-sm">
                  <strong>😷 Khuyến nghị:</strong> Sử dụng khẩu trang khi ra ngoài
                </p>
              </div>
              <div className="p-4 bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl shadow-md text-white">
                <p className="text-sm">
                  <strong>✅ Tình trạng tổng quát:</strong> Chấp nhận được cho hoạt động thường ngày
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 24-hour Forecast */}
      <Card className="border-0 shadow-lg bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <div className="bg-gradient-to-br from-indigo-500 to-purple-500 p-2 rounded-lg">
              <Sun className="h-5 w-5 text-white" />
            </div>
            Dự báo 24 giờ tới
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-3 overflow-x-auto pb-2">
            {hourlyForecast.map((hour, index) => (
              <div 
                key={index} 
                className="flex flex-col items-center space-y-2 min-w-[90px] bg-white rounded-xl p-4 shadow-sm hover:shadow-md transition-all hover:scale-105"
              >
                <p className="text-sm text-muted-foreground">{hour.time}</p>
                <div className="bg-gradient-to-br from-blue-100 to-cyan-100 p-2 rounded-lg">
                  {getWeatherIcon(hour.condition)}
                </div>
                <p className="text-lg bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">{hour.temp}°</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}