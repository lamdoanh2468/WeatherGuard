import { useState, useEffect } from 'react';
import { weatherService, WeatherData, AirQualityData } from '../services/weatherService';

export interface CombinedWeatherData {
  weather: WeatherData | null;
  airQuality: AirQualityData | null;
  forecast: any[];
  loading: boolean;
  error: string | null;
  lastUpdated: Date | null;
}

/**
 * Custom hook để quản lý dữ liệu thời tiết và chất lượng không khí
 */
export function useWeatherData(city: string = 'Hanoi', autoRefresh: boolean = true) {
  const [data, setData] = useState<CombinedWeatherData>({
    weather: null,
    airQuality: null,
    forecast: [],
    loading: true,
    error: null,
    lastUpdated: null
  });

  const fetchWeatherData = async () => {
    try {
      setData(prev => ({ ...prev, loading: true, error: null }));

      // Gọi các API song song để tối ưu tốc độ
      const [weatherData, airQualityData, forecastData] = await Promise.all([
        weatherService.getCurrentWeather(city),
        weatherService.getAirQuality(city.toLowerCase()),
        weatherService.getForecast(city)
      ]);

      setData({
        weather: weatherData,
        airQuality: airQualityData,
        forecast: forecastData,
        loading: false,
        error: null,
        lastUpdated: new Date()
      });
    } catch (error) {
      console.warn('Lỗi khi tải dữ liệu thời tiết, sử dụng dữ liệu mô phỏng:', error);
      // Không set error nữa, vì service đã tự động fallback về mock data
      setData(prev => ({
        ...prev,
        loading: false,
        error: null
      }));
    }
  };

  // Tải dữ liệu ban đầu
  useEffect(() => {
    fetchWeatherData();
  }, [city]);

  // Tự động refresh mỗi 10 phút nếu autoRefresh = true
  useEffect(() => {
    if (!autoRefresh) return;

    const interval = setInterval(() => {
      fetchWeatherData();
    }, 10 * 60 * 1000); // 10 phút

    return () => clearInterval(interval);
  }, [city, autoRefresh]);

  return {
    ...data,
    refetch: fetchWeatherData
  };
}

/**
 * Hook để lấy dữ liệu thời tiết theo vị trí hiện tại
 */
export function useCurrentLocationWeather() {
  const [data, setData] = useState<CombinedWeatherData>({
    weather: null,
    airQuality: null,
    forecast: [],
    loading: true,
    error: null,
    lastUpdated: null
  });
  const [location, setLocation] = useState<{ lat: number; lon: number } | null>(null);

  const fetchLocationWeather = async () => {
    try {
      setData(prev => ({ ...prev, loading: true, error: null }));

      // Lấy vị trí hiện tại
      const coords = await weatherService.getCurrentLocation();
      
      if (!coords) {
        console.warn('Không thể xác định vị trí hiện tại, sử dụng dữ liệu mặc định');
        // Fallback về dữ liệu mặc định thay vì throw error
        const weatherData = await weatherService.getCurrentWeather('Hanoi');
        const airQualityData = await weatherService.getAirQuality('hanoi');
        
        setData({
          weather: weatherData,
          airQuality: airQualityData,
          forecast: [],
          loading: false,
          error: null,
          lastUpdated: new Date()
        });
        return;
      }

      setLocation(coords);

      // Lấy dữ liệu thời tiết theo tọa độ
      const weatherData = await weatherService.getWeatherByCoords(coords);
      
      // Với air quality, ta cần reverse geocoding để lấy tên thành phố
      // Tạm thời dùng dữ liệu mặc định
      const airQualityData = await weatherService.getAirQuality('hanoi');

      setData({
        weather: weatherData,
        airQuality: airQualityData,
        forecast: [],
        loading: false,
        error: null,
        lastUpdated: new Date()
      });
    } catch (error) {
      console.warn('Lỗi khi tải dữ liệu vị trí, sử dụng dữ liệu mô phỏng:', error);
      setData(prev => ({
        ...prev,
        loading: false,
        error: null
      }));
    }
  };

  useEffect(() => {
    fetchLocationWeather();
  }, []);

  return {
    ...data,
    location,
    refetch: fetchLocationWeather
  };
}
