# Weather & Environment Monitoring App

Ứng dụng giám sát thời tiết và môi trường với giao diện trực quan, hiển thị dữ liệu thời gian thực từ các nguồn uy tín như OpenWeatherMap và AQICN.

## 🌟 Tính năng chính

### 1. Dashboard Thời tiết
- Hiển thị các chỉ số thời tiết quan trọng: nhiệt độ, độ ẩm, tốc độ gió, tầm nhìn
- Theo dõi chất lượng không khí (AQI) và các chỉ số môi trường (PM2.5, PM10, NO₂, SO₂, CO)
- Dự báo thời tiết 24 giờ tới
- Khuyến nghị sức khỏe dựa trên điều kiện môi trường
- Tự động refresh dữ liệu mỗi 10 phút

### 2. Biểu đồ & Phân tích
- Biểu đồ nhiệt độ và độ ẩm theo thời gian
- Theo dõi xu hướng chỉ số AQI
- Phân tích thành phần ô nhiễm không khí
- Báo cáo tổng hợp theo tuần

### 3. Bản đồ Môi trường
- Hiển thị dữ liệu môi trường trên bản đồ
- Xem chất lượng không khí theo khu vực
- Các điểm quan trắc với màu sắc biểu thị mức độ ô nhiễm
- Cảnh báo cho các khu vực có chất lượng không khí kém

### 4. Cảnh báo & Thông báo
- Cảnh báo khi các chỉ số vượt ngưỡng an toàn
- Tùy chỉnh ngưỡng cảnh báo cá nhân
- Lịch sử cảnh báo
- Quản lý vị trí theo dõi

### 5. Cấu hình API
- Giao diện trực quan để nhập API keys
- Hướng dẫn chi tiết cách lấy API keys từ OpenWeatherMap và AQICN
- Thông báo về tình trạng kết nối API

## 🚀 Bắt đầu sử dụng

### Bước 1: Lấy API Keys

#### OpenWeatherMap API Key
1. Truy cập [OpenWeatherMap](https://openweathermap.org/api)
2. Đăng ký tài khoản miễn phí
3. Vào phần "API keys" trong tài khoản
4. Tạo API key mới hoặc sao chép key hiện có
5. Free tier: 1,000 lượt gọi/ngày

#### AQICN API Token
1. Truy cập [AQICN Data Platform](https://aqicn.org/data-platform/token/)
2. Điền thông tin đăng ký (email, tên, mục đích sử dụng)
3. Nhận token qua email
4. Free tier: Không giới hạn lượt gọi (sử dụng hợp lý)

### Bước 2: Cấu hình API Keys trong ứng dụng
1. Mở ứng dụng
2. Vào tab **"Cấu hình API"** trong menu
3. Nhập API keys vào các ô tương ứng
4. Nhấn nút **"Lưu API Keys"**
5. Reload trang để áp dụng cấu hình

### Bước 3: Sử dụng ứng dụng
Sau khi cấu hình API keys, ứng dụng sẽ tự động:
- Lấy dữ liệu thời tiết hiện tại
- Cập nhật chất lượng không khí
- Hiển thị dự báo thời tiết
- Refresh dữ liệu định kỳ

## 📊 Nguồn dữ liệu

### OpenWeatherMap
- Dữ liệu thời tiết toàn cầu
- Nhiệt độ, độ ẩm, áp suất, tốc độ gió
- Dự báo thời tiết 5 ngày
- Cập nhật mỗi 10 phút

### AQICN (World Air Quality Index)
- Dữ liệu chất lượng không khí toàn cầu
- Hơn 12,000 trạm quan trắc
- Chỉ số AQI, PM2.5, PM10, NO₂, SO₂, CO, O₃
- Dữ liệu từ các cơ quan môi trường uy tín

## ⚠️ Lưu ý quan trọng

### Bảo mật API Keys
**CẢNH BÁO:** Hiện tại API keys được lưu trong localStorage của trình duyệt. Đây KHÔNG phải là cách lưu trữ an toàn cho môi trường production.

**Khuyến nghị:**
- API keys có thể bị lộ thông qua Developer Tools
- Không nên chia sẻ máy tính với người khác khi đã lưu API keys
- Trong production, cần sử dụng backend (như Supabase) để lưu trữ và xử lý API keys an toàn

### Giới hạn API
- **OpenWeatherMap Free:** 1,000 calls/ngày, 60 calls/phút
- **AQICN Free:** Không giới hạn chính thức, nhưng nên sử dụng hợp lý

## 🔄 Tự động Refresh
Ứng dụng tự động refresh dữ liệu mỗi 10 phút để đảm bảo thông tin luôn cập nhật. Bạn cũng có thể nhấn nút "Làm mới" để cập nhật thủ công.

## 🎯 Kế hoạch phát triển

### Tính năng sắp tới
- [ ] Tích hợp Supabase để lưu trữ an toàn
- [ ] Lưu lịch sử dữ liệu dài hạn
- [ ] Push notifications cho cảnh báo
- [ ] AI dự báo xu hướng 24-72 giờ
- [ ] So sánh dữ liệu giữa nhiều địa điểm
- [ ] Export dữ liệu ra CSV/PDF
- [ ] Tích hợp thêm nguồn dữ liệu IoT

### Cải thiện bảo mật
- [ ] Backend API proxy để bảo vệ API keys
- [ ] Authentication và user management
- [ ] Rate limiting
- [ ] Data encryption

## 🛠️ Stack công nghệ
- **Frontend:** React, TypeScript, Tailwind CSS
- **UI Components:** Shadcn/ui
- **Charts:** Recharts
- **Icons:** Lucide React
- **APIs:** OpenWeatherMap, AQICN

## 📝 Ghi chú
- Ứng dụng yêu cầu kết nối internet để lấy dữ liệu
- Chất lượng dữ liệu phụ thuộc vào nguồn API
- Một số khu vực có thể không có dữ liệu đầy đủ
- Dữ liệu AQI có thể khác nhau giữa các nguồn do phương pháp tính toán khác nhau

## 🤝 Đóng góp
Đây là ứng dụng demo được xây dựng bằng Figma Make. Mọi góp ý và đề xuất đều được hoan nghênh!

## 📄 License
MIT License - Sử dụng tự do cho mục đích học tập và phát triển.

---

**Lưu ý:** Ứng dụng này được thiết kế cho mục đích giáo dục và demo. Không sử dụng để thu thập dữ liệu cá nhân nhạy cảm (PII) hoặc thông tin bảo mật.
