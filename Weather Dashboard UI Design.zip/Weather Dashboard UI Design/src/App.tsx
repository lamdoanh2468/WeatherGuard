import { useState, useEffect } from 'react';
import { Navigation } from "./components/Navigation";
import { Dashboard } from "./components/Dashboard";
import { Charts } from "./components/Charts";
import { Maps } from "./components/Maps";
import { Alerts } from "./components/Alerts";
import { Account } from "./components/Account";
import { ApiKeySetup } from "./components/ApiKeySetup";
import { WelcomeScreen } from "./components/WelcomeScreen";

export default function App() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [showWelcome, setShowWelcome] = useState(false);

  useEffect(() => {
    // Kiểm tra nếu là lần đầu truy cập
    const hasVisited = localStorage.getItem('has_visited');
    if (!hasVisited) {
      setShowWelcome(true);
    }
  }, []);

  const handleGetStarted = () => {
    localStorage.setItem('has_visited', 'true');
    setShowWelcome(false);
  };

  if (showWelcome) {
    return <WelcomeScreen onGetStarted={handleGetStarted} />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case "dashboard":
        return <Dashboard />;
      case "charts":
        return <Charts />;
      case "maps":
        return <Maps />;
      case "alerts":
        return <Alerts />;
      case "api-setup":
        return <ApiKeySetup />;
      case "account":
        return <Account />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-cyan-50">
      <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />
      
      {/* Main Content */}
      <div className="md:pl-64 pt-16">
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}