// Weather Service - Tích hợp OpenWeatherMap và AQICN APIs
// Lưu ý: Trong production, API keys nên được lưu trữ an toàn ở backend

export interface WeatherData {
  location: string;
  temperature: number;
  humidity: number;
  windSpeed: number;
  visibility: number;
  condition: string;
  conditionText: string;
  pressure: number;
  feelsLike: number;
  uvIndex: number;
  timestamp: string;
}

export interface AirQualityData {
  aqi: number;
  pm25: number;
  pm10: number;
  no2: number;
  so2: number;
  co: number;
  o3: number;
  status: string;
  timestamp: string;
}

export interface LocationCoords {
  lat: number;
  lon: number;
}

class WeatherService {
  private baseWeatherUrl = 'https://api.openweathermap.org/data/2.5';
  private baseAirQualityUrl = 'https://api.waqi.info';
  
  // Lấy API keys từ localStorage hoặc sử dụng giá trị mặc định
  private getOpenWeatherKey(): string {
    return localStorage.getItem('openweather_api_key') || '';
  }
  
  private getAqicnKey(): string {
    return localStorage.getItem('aqicn_api_key') || '';
  }
  
  // Kiểm tra xem có API key hợp lệ không
  private hasValidOpenWeatherKey(): boolean {
    const key = this.getOpenWeatherKey();
    return key !== '' && key !== 'YOUR_OPENWEATHERMAP_API_KEY';
  }
  
  private hasValidAqicnKey(): boolean {
    const key = this.getAqicnKey();
    return key !== '' && key !== 'YOUR_AQICN_API_KEY';
  }
  
  /**
   * Lấy dữ liệu thời tiết hiện tại từ OpenWeatherMap
   */
  async getCurrentWeather(city: string = 'Hanoi'): Promise<WeatherData | null> {
    // Nếu không có API key hợp lệ, trả về mock data ngay
    if (!this.hasValidOpenWeatherKey()) {
      console.log('Đang sử dụng dữ liệu mô phỏng (chưa cấu hình API key)');
      return this.getMockWeatherData();
    }

    try {
      const apiKey = this.getOpenWeatherKey();
      const response = await fetch(
        `${this.baseWeatherUrl}/weather?q=${city}&appid=${apiKey}&units=metric&lang=vi`
      );
      
      if (!response.ok) {
        console.warn('API call failed, using mock data');
        return this.getMockWeatherData();
      }
      
      const data = await response.json();
      
      return {
        location: `${data.name}, ${data.sys.country}`,
        temperature: Math.round(data.main.temp),
        humidity: data.main.humidity,
        windSpeed: Math.round(data.wind.speed * 3.6), // Chuyển m/s sang km/h
        visibility: Math.round(data.visibility / 1000), // Chuyển m sang km
        condition: this.mapWeatherCondition(data.weather[0].main),
        conditionText: data.weather[0].description,
        pressure: data.main.pressure,
        feelsLike: Math.round(data.main.feels_like),
        uvIndex: 0, // Cần API riêng để lấy UV index
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.warn('Lỗi khi lấy dữ liệu thời tiết, sử dụng dữ liệu mô phỏng:', error);
      return this.getMockWeatherData();
    }
  }

  /**
   * Lấy dữ liệu chất lượng không khí từ AQICN
   */
  async getAirQuality(city: string = 'hanoi'): Promise<AirQualityData | null> {
    // Nếu không có API key hợp lệ, trả về mock data ngay
    if (!this.hasValidAqicnKey()) {
      console.log('Đang sử dụng dữ liệu mô phỏng chất lượng không khí (chưa cấu hình API key)');
      return this.getMockAirQualityData();
    }

    try {
      const apiKey = this.getAqicnKey();
      const response = await fetch(
        `${this.baseAirQualityUrl}/feed/${city}/?token=${apiKey}`
      );
      
      if (!response.ok) {
        console.warn('AQI API call failed, using mock data');
        return this.getMockAirQualityData();
      }
      
      const data = await response.json();
      
      if (data.status !== 'ok') {
        console.warn('Invalid AQI data, using mock data');
        return this.getMockAirQualityData();
      }
      
      const aqiData = data.data;
      const iaqi = aqiData.iaqi || {};
      
      return {
        aqi: aqiData.aqi || 0,
        pm25: iaqi.pm25?.v || 0,
        pm10: iaqi.pm10?.v || 0,
        no2: iaqi.no2?.v || 0,
        so2: iaqi.so2?.v || 0,
        co: iaqi.co?.v || 0,
        o3: iaqi.o3?.v || 0,
        status: this.getAQIStatus(aqiData.aqi),
        timestamp: aqiData.time?.iso || new Date().toISOString()
      };
    } catch (error) {
      console.warn('Lỗi khi lấy dữ liệu chất lượng không khí, sử dụng dữ liệu mô phỏng:', error);
      return this.getMockAirQualityData();
    }
  }

  /**
   * Lấy dữ liệu thời tiết theo tọa độ
   */
  async getWeatherByCoords(coords: LocationCoords): Promise<WeatherData | null> {
    // Nếu không có API key hợp lệ, trả về mock data ngay
    if (!this.hasValidOpenWeatherKey()) {
      console.log('Đang sử dụng dữ liệu mô phỏng (chưa cấu hình API key)');
      return this.getMockWeatherData();
    }

    try {
      const apiKey = this.getOpenWeatherKey();
      const response = await fetch(
        `${this.baseWeatherUrl}/weather?lat=${coords.lat}&lon=${coords.lon}&appid=${apiKey}&units=metric&lang=vi`
      );
      
      if (!response.ok) {
        console.warn('Weather API call failed, using mock data');
        return this.getMockWeatherData();
      }
      
      const data = await response.json();
      
      return {
        location: `${data.name}, ${data.sys.country}`,
        temperature: Math.round(data.main.temp),
        humidity: data.main.humidity,
        windSpeed: Math.round(data.wind.speed * 3.6),
        visibility: Math.round(data.visibility / 1000),
        condition: this.mapWeatherCondition(data.weather[0].main),
        conditionText: data.weather[0].description,
        pressure: data.main.pressure,
        feelsLike: Math.round(data.main.feels_like),
        uvIndex: 0,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.warn('Lỗi khi lấy dữ liệu thời tiết, sử dụng dữ liệu mô phỏng:', error);
      return this.getMockWeatherData();
    }
  }

  /**
   * Lấy dự báo thời tiết 5 ngày
   */
  async getForecast(city: string = 'Hanoi'): Promise<any[]> {
    // Nếu không có API key hợp lệ, trả về mock data ngay
    if (!this.hasValidOpenWeatherKey()) {
      console.log('Đang sử dụng dữ liệu dự báo mô phỏng (chưa cấu hình API key)');
      return this.getMockForecastData();
    }

    try {
      const apiKey = this.getOpenWeatherKey();
      const response = await fetch(
        `${this.baseWeatherUrl}/forecast?q=${city}&appid=${apiKey}&units=metric&lang=vi`
      );
      
      if (!response.ok) {
        console.warn('Forecast API call failed, using mock data');
        return this.getMockForecastData();
      }
      
      const data = await response.json();
      
      // Lấy 8 dữ liệu đầu tiên (24 giờ, mỗi 3 giờ)
      return data.list.slice(0, 8).map((item: any) => ({
        time: new Date(item.dt * 1000).getHours() + 'h',
        temp: Math.round(item.main.temp),
        condition: this.mapWeatherCondition(item.weather[0].main),
        humidity: item.main.humidity,
        description: item.weather[0].description
      }));
    } catch (error) {
      console.warn('Lỗi khi lấy dữ liệu dự báo, sử dụng dữ liệu mô phỏng:', error);
      return this.getMockForecastData();
    }
  }

  /**
   * Lấy vị trí hiện tại của người dùng
   */
  async getCurrentLocation(): Promise<LocationCoords | null> {
    return new Promise((resolve) => {
      if (!navigator.geolocation) {
        resolve(null);
        return;
      }
      
      navigator.geolocation.getCurrentPosition(
        (position) => {
          resolve({
            lat: position.coords.latitude,
            lon: position.coords.longitude
          });
        },
        (error) => {
          console.error('Không thể lấy vị trí:', error);
          resolve(null);
        }
      );
    });
  }

  /**
   * Map điều kiện thời tiết từ OpenWeatherMap sang định dạng nội bộ
   */
  private mapWeatherCondition(condition: string): string {
    const conditionMap: { [key: string]: string } = {
      'Clear': 'sunny',
      'Clouds': 'cloudy',
      'Rain': 'rainy',
      'Drizzle': 'rainy',
      'Thunderstorm': 'stormy',
      'Snow': 'snowy',
      'Mist': 'cloudy',
      'Fog': 'cloudy',
      'Haze': 'cloudy'
    };
    
    return conditionMap[condition] || 'partly-cloudy';
  }

  /**
   * Xác định trạng thái AQI
   */
  private getAQIStatus(aqi: number): string {
    if (aqi <= 50) return 'good';
    if (aqi <= 100) return 'moderate';
    if (aqi <= 150) return 'unhealthy-sensitive';
    if (aqi <= 200) return 'unhealthy';
    if (aqi <= 300) return 'very-unhealthy';
    return 'hazardous';
  }

  /**
   * Dữ liệu mock cho thời tiết khi không có API key hoặc lỗi
   */
  private getMockWeatherData(): WeatherData {
    return {
      location: 'Hà Nội, Việt Nam',
      temperature: 28,
      humidity: 75,
      windSpeed: 12,
      visibility: 8,
      condition: 'partly-cloudy',
      conditionText: 'Có mây',
      pressure: 1013,
      feelsLike: 30,
      uvIndex: 5,
      timestamp: new Date().toISOString()
    };
  }

  /**
   * Dữ liệu mock cho chất lượng không khí
   */
  private getMockAirQualityData(): AirQualityData {
    return {
      aqi: 85,
      pm25: 35,
      pm10: 45,
      no2: 25,
      so2: 15,
      co: 0.8,
      o3: 45,
      status: 'moderate',
      timestamp: new Date().toISOString()
    };
  }

  /**
   * Dữ liệu mock cho dự báo
   */
  private getMockForecastData() {
    return [
      { time: '6h', temp: 25, condition: 'sunny', humidity: 70 },
      { time: '9h', temp: 27, condition: 'partly-cloudy', humidity: 65 },
      { time: '12h', temp: 30, condition: 'cloudy', humidity: 60 },
      { time: '15h', temp: 32, condition: 'partly-cloudy', humidity: 55 },
      { time: '18h', temp: 29, condition: 'cloudy', humidity: 65 },
      { time: '21h', temp: 26, condition: 'rainy', humidity: 80 },
      { time: '24h', temp: 24, condition: 'rainy', humidity: 85 },
      { time: '3h', temp: 23, condition: 'cloudy', humidity: 82 }
    ];
  }
}

// Export singleton instance
export const weatherService = new WeatherService();
